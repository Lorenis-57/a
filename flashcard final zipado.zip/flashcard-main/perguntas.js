criaCartao(
    'Geek',
    'Otaku é gente?',
    'Não'
)

criaCartao(
    'Geral',
    'O que acontece com as encomendas quando caem no oceano?',
    'Molha'
)

criaCartao(
    'Cultura',
    'Vc sabe o que é caviar?',
    'Nunca vi nem comi eu só ouço falar'
)

criaCartao(
    'Publi',
    'Hotel?',
    'Trivago'
)